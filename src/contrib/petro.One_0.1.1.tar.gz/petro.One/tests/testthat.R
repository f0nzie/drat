library(testthat)
library(petro.One)

test_check("petro.One")
